from pathlib import Path
import cadquery as cq,numpy as np,json
from PIL import Image
D=Path(__file__).parent;B=D.parent/'restored/v64'
r=np.load(D/'registration.npz');R=r['R'];s=float(r['scale']);t=r['trans']
im=np.array(Image.open(D/'reference.png').convert('RGB'));mask=(im[:,:,0]>100)&(im[:,:,1]>140)&(im[:,:,2]<80)
def pt(x,y,z):
 q=np.array([x,-y])@R*s+t
 return cq.Vector(float(q[0]),float(q[1]),float(z*s))
wires=[];sections=[]
for x in np.linspace(108,285,9):
 xi=round(x);ys=np.where(mask[240:360,xi])[0]+240;yt=float(ys.min());yb=float(ys.max()); zs=np.where(mask[30:230,xi])[0];w=float((zs.max()-zs.min())/2)
 h=max(3,yb-yt);yb=yt+h
 radius=(w*w+h*h)/(2*h); center=yb+radius-h
 pts=[pt(x,yb-h*max(0,1-(z/w)**2)**0.25,z) for z in np.linspace(w,-w,25)]
 arc=cq.Edge.makeSpline(pts);line=cq.Edge.makeLine(pts[-1],pts[0]);wires.append(cq.Wire.assembleEdges([arc,line]));sections.append([float(x),yt,yb,w])
solid=cq.Solid.makeLoft(wires)
print('loft',solid.isValid(),len(solid.Faces()),flush=True)
# Remove the underside and both transverse end faces; retain curved roof.
faces=solid.Faces()
for i,f in enumerate(faces):print(i,f.Area(),f.geomType(),flush=True)
# Loft has two longitudinal faces followed by end caps. Curved roof is largest.
roof=max(faces,key=lambda f:f.Area());remove=[f for f in faces if not f.isSame(roof)]
from OCP.BRepOffsetAPI import BRepOffsetAPI_MakeThickSolid
builder=BRepOffsetAPI_MakeThickSolid()
builder.MakeThickSolidBySimple(roof.wrapped,-1.5)
shell=cq.Shape.cast(builder.Shape())
print('shell',shell.isValid(),shell.Volume(),len(shell.Solids()),flush=True)
cq.exporters.export(shell,str(D/'P12.step'));cq.exporters.export(shell,str(D/'P12.stl'),tolerance=.2)
(D/'sections.json').write_text(json.dumps(sections))
