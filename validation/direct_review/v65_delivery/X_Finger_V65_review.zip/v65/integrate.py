from pathlib import Path
import json,cadquery as cq,shutil
D=Path(__file__).parent;B=D.parent/'restored/v64'
data=json.loads((B/'viewer_data.json').read_text());s=cq.importers.importStep(str(D/'P12.step')).val();v,f=s.tessellate(.35,.15)
data['models'].append({'id':'P12','parent':'P01','name':'Крышка над чёрной деталью — V6.5','color':'#344326','v':[list(p.toTuple()) for p in v],'f':f})
(D/'viewer_data.json').write_text(json.dumps(data,separators=(',',':')))
h=(B/'assembly_viewer_v64.html').read_text();i=h.index('const data=')+len('const data=');j=h.index(';const canvas=',i);h=h[:i]+json.dumps(data,separators=(',',':'))+h[j:];h=h.replace('V6.4','V6.5').replace('Новая чаша: проверка движения выполняется.','Крышка P12: стенка 1,5 мм в существующем масштабе STEP. Проверочный вариант.')
(D/'assembly_viewer_v65.html').write_text(h)
a=cq.Assembly()
for p in sorted(B.glob('P*.step')):a.add(cq.importers.importStep(str(p)).val(),name=p.stem)
a.add(s,name='P12',color=cq.Color(0.20,0.26,0.15));a.save(str(D/'assembly_v65.step'))

print('integrated',len(data['models']),len(data['motion']))
