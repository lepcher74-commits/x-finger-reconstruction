from pathlib import Path
import trimesh,numpy as np,json
D=Path(__file__).parent;d=json.loads((D/'viewer_data.json').read_text());mgr=trimesh.collision.CollisionManager();parents={}
for m in d['models']:
 mgr.add_object(m['id'],trimesh.Trimesh(m['v'],m['f'],process=False));parents[m['id']]=m['parent']
cover=next(m for m in d['models'] if m['id']=='P12'); mesh=trimesh.Trimesh(cover['v'],cover['f'],process=False);mgr.remove_object('P12');mgr.remove_object('P01')
errors=[];mindist=1e9
for i,frame in enumerate(d['motion']):
 def matrix(parent):
  t=frame['transforms'][parent];a=t['angle'];T=np.eye(4);T[:2,:2]=[[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]];T[:2,3]=t['translation'];return T
 for name in list(mgr._objs):mgr.set_transform(name,matrix(parents[name]))
 hit,names=mgr.in_collision_single(mesh,matrix('P01'),return_names=True)
 if hit:errors.append({'frame':i,'parts':sorted(names)})
 mindist=min(mindist,mgr.min_distance_single(mesh,matrix('P01')))
print('mesh collisions',errors,'minimum distance',mindist)
(D/'mesh_validation.json').write_text(json.dumps({'frames':len(d['motion']),'collisions':errors,'minimum_mesh_distance':mindist,'method':'FCL triangle meshes; approximate tessellation, not exact BRep; parent contact excluded'},indent=2))
