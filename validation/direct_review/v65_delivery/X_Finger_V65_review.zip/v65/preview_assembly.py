import cadquery as cq,numpy as np
from pathlib import Path
from PIL import Image,ImageDraw
D=Path(__file__).parent
import json
models=[]
for m in json.loads((D/'viewer_data.json').read_text())['models']:
 rgb=tuple(int(m['color'][i:i+2],16) for i in [1,3,5]);models.append((np.array(m['v']),np.array(m['f']),rgb))
im=Image.new('RGB',(1000,650),'white');draw=ImageDraw.Draw(im);tri=[]
a=.65;b=.45;R=np.array([[np.cos(a),0,np.sin(a)],[np.sin(a)*np.sin(b),np.cos(b),-np.cos(a)*np.sin(b)],[-np.sin(a)*np.cos(b),np.sin(b),np.cos(a)*np.cos(b)]])
for v,f,col in models:
 v=(v-np.array([805,-600,15]))@R.T
 for pts in v[f]:
  n=np.cross(pts[1]-pts[0],pts[2]-pts[0]);n/=max(np.linalg.norm(n),1e-9);shade=.5+.5*abs(n@np.array([.2,.5,.84]));tri.append((pts[:,2].mean(),pts[:,:2],tuple(int(c*shade) for c in col)))
# Per-pixel depth rasterization avoids painter-order artifacts.
canvas=np.full((650,1000,3),255,dtype=np.uint8);depth=np.full((650,1000),-np.inf)
for verts,faces,col in models:
 vv=(verts-np.array([805,-600,15]))@R.T
 for pts in vv[faces]:
  n=np.cross(pts[1]-pts[0],pts[2]-pts[0]);n/=max(np.linalg.norm(n),1e-9);shade=.5+.5*abs(n@np.array([.2,.5,.84]));color=np.array(col)*shade
  pp=pts[:,:2]*np.array([0.85,-0.85])+[500,325];lo=np.maximum(np.floor(pp.min(0)).astype(int),[0,0]);hi=np.minimum(np.ceil(pp.max(0)).astype(int),[999,649])
  if np.any(hi<lo):continue
  x,y=np.meshgrid(np.arange(lo[0],hi[0]+1),np.arange(lo[1],hi[1]+1));a,b,c=pp;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
  if abs(den)<1e-9:continue
  u=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/den;v=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/den;w=1-u-v;z=u*pts[0,2]+v*pts[1,2]+w*pts[2,2]
  sl=np.s_[lo[1]:hi[1]+1,lo[0]:hi[0]+1];hit=(u>=0)&(v>=0)&(w>=0)&(z>depth[sl]);depth[sl][hit]=z[hit];canvas[sl][hit]=color
im=Image.fromarray(canvas)
im.save(D/'assembly_preview.png')
