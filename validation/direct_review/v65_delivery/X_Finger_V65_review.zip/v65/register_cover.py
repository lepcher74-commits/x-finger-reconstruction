from pathlib import Path
import numpy as np,cadquery as cq,json
from PIL import Image,ImageDraw
D=Path(__file__).parent; B=D.parent/'restored/v64'
a=np.array([[117,369],[271,346],[290,295]],float);b=np.array([[497.334008,-440.385073],[645.944676,-453.824913],[675.054788,-411.133296]])
a[:,1]*=-1
ac=a.mean(0);bc=b.mean(0);u,s,v=np.linalg.svd((a-ac).T@(b-bc));R=u@v;scale=s.sum()/((a-ac)**2).sum();trans=bc-ac@R*scale
print(scale,R,trans,'errors',np.linalg.norm(a@R*scale+trans-b,axis=1))
np.savez(D/'registration.npz',R=R,scale=scale,trans=trans)
shape=cq.importers.importStep(str(B/'P01.step')).val();vs,fs=shape.tessellate(.3);q=(np.array([v.toTuple() for v in vs])[:,:2]-trans)@R.T/scale;q[:,1]*=-1
im=Image.open(D/'reference.png').convert('RGB');draw=ImageDraw.Draw(im)
for f in fs:draw.line([tuple(q[i]) for i in [*f,f[0]]],fill='#d04747',width=1)
im.save(D/'registration.png')
print('bounds in drawing',q.min(0),q.max(0))
