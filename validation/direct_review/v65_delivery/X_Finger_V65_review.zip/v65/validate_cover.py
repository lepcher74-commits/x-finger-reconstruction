from pathlib import Path
import json,math,cadquery as cq
D=Path(__file__).parent;B=D.parent/'restored/v64'
data=json.loads((D/'viewer_data.json').read_text());parents={m['id']:m['parent'] for m in data['models']};parts={p.stem:cq.importers.importStep(str(p)).val() for p in B.glob('P*.step')};cover=cq.importers.importStep(str(D/'P12.step')).val()
report={'valid':cover.isValid(),'solids':len(cover.Solids()),'wall_offset_mm':1.5,'scale':'Existing STEP millimetres, no rescaling. Physical manufactured scale not independently established.','parent':'P01','contact_volume':cover.intersect(parts['P01']).Volume(),'collisions':[],'completed':0,'total':len(data['motion'])}
for m in data['models']:
 if m['id'].startswith('J'):
  vv=m['v'];lo=[min(p[i] for p in vv) for i in range(3)];hi=[max(p[i] for p in vv) for i in range(3)]
  parts[m['id']]=cq.Solid.makeCylinder(4.8,hi[2]-lo[2],cq.Vector((lo[0]+hi[0])/2,(lo[1]+hi[1])/2,lo[2]))
def move(s,t):return s.rotate((0,0,0),(0,0,1),math.degrees(t['angle'])).translate((*t['translation'],0))
for i,frame in enumerate(data['motion']):
 a=move(cover,frame['transforms']['P01']);ba=a.BoundingBox()
 for p,s in parts.items():
  if p=='P01':continue
  b=move(s,frame['transforms'][parents[p]]);bb=b.BoundingBox()
  if any(getattr(ba,k+'max')<getattr(bb,k+'min') or getattr(bb,k+'max')<getattr(ba,k+'min') for k in 'xyz'):continue
  v=sum(x.Volume() for x in a.intersect(b).Solids())
  if v>1e-3:report['collisions'].append({'frame':i,'part':p,'volume':v})
 report['completed']=i+1;(D/'validation_report.json').write_text(json.dumps(report,indent=2))
 print(i+1,'/',len(data['motion']),'collisions',len(report['collisions']),flush=True)
