from pathlib import Path
import cadquery as cq,numpy as np,json
from PIL import Image
D=Path(__file__).parent;B=D.parent/'restored/v64';r=np.load(D/'registration.npz');R=r['R'];s=float(r['scale']);t=r['t']
old=cq.importers.importStep(str(D/'P02_original.step')).val();im=np.array(Image.open(D/'reference.png').convert('RGB'));mask=(im[:,:,2]>im[:,:,0]*1.3)&(im[:,:,0]<120)&(im[:,:,2]>90)
def pt(x,y,z):
 q=np.array([x,-y])@R*s+t;return cq.Vector(float(q[0]),float(q[1]),float(z*s))
sections=[];wires=[]
for x in np.linspace(344,525,28):
 ix=int(round(x));yy=np.where(mask[368:462,ix])[0]+368;zz=np.where(mask[106:265,ix])[0]+106
 yt=float(yy.min());yb=float(yy.max())
 if len(zz)==0:zz=np.where(mask[106:265,ix-2:ix+3].any(axis=1))[0]+106
 w=(zz.max()-zz.min())/2;edge=yt+.54*(yb-yt)
 # Closed lens cross-section from front/rear drawing: upper and lower rounded lobes.
 points=[]
 for a in np.linspace(0,2*np.pi,65)[:-1]:
  z=w*np.cos(a);y=edge-(edge-yt)*np.sin(a) if a<=np.pi else edge-(yb-edge)*np.sin(a)
  points.append(pt(x,y,z))
 curve=cq.Edge.makeSpline(points,periodic=True);wires.append(cq.Wire.assembleEdges([curve]));sections.append([float(x),yt,yb,float(w)])
envelope=cq.Solid.makeLoft(wires,ruled=True)
# Rear central lug follows the side silhouette and keeps original transverse span.
b=old.BoundingBox()
upper=[];lower=[]
for x in range(506,544):
 yy=np.where(mask[368:462,x])[0]+368
 if len(yy):upper.append((x,float(yy.min())));lower.append((x,float(yy.max())))
pts=[pt(x,y,-31.6) for x,y in upper+lower[::-1]]
wire=cq.Wire.makePolygon(pts+[pts[0]])
lug=cq.Solid.extrudeLinear(wire,[],cq.Vector(0,0,63.2*s))
new=envelope.fuse(lug)
for x,y in [(467.13164117961,-468.957897705),(498.977264396,-441.0703027881)]:
 new=new.cut(cq.Solid.makeCylinder(5.3,400,cq.Vector(x,y,-200)))
# Restore the existing internal passage throughout P03 swept x/z bounds.
slot_region=cq.Solid.makeBox(250,250,24.4,cq.Vector(451.5,-600,-12.2))
old_passage=slot_region.cut(old)
new=new.cut(old_passage).clean()
assert new.isValid() and len(new.Solids())==1
cq.exporters.export(new,str(D/'P02.step'));cq.exporters.export(new,str(D/'P02.stl'),tolerance=.2)
report={'valid':new.isValid(),'solids':len(new.Solids()),'old_width':b.zlen,'new_width':new.BoundingBox().zlen,'old_volume':old.Volume(),'new_volume':new.Volume(),'method':'New lens envelope and rear lug from drawing; original bore axes and 5.3 mm radii retained','limitations':['Raster-derived transverse profile','Central body rebuilt; motion clearance must be rechecked','Front/rear silhouette requires visual review']}
(D/'build_report.json').write_text(json.dumps(report,indent=2));(D/'sections.json').write_text(json.dumps(sections));print(report,flush=True)
