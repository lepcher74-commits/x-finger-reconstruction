from pathlib import Path
import trimesh,numpy as np,json
D=Path(__file__).parent;d=json.loads((D/'viewer_data.json').read_text());baseline=json.loads((D/'baseline_viewer_data.json').read_text());mgr=trimesh.collision.CollisionManager();parents={}
for m in d['models']:
 if m['id']=='P02':continue
 mgr.add_object(m['id'],trimesh.Trimesh(m['v'],m['f'],process=False));parents[m['id']]=m['parent']
meshes=[]
for data in [baseline,d]:
 m=next(m for m in data['models'] if m['id']=='P02');meshes.append(trimesh.Trimesh(m['v'],m['f'],process=False))
rows=[]
for i,frame in enumerate(d['motion']):
 def T(parent):
  t=frame['transforms'][parent];a=t['angle'];mat=np.eye(4);mat[:2,:2]=[[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]];mat[:2,3]=t['translation'];return mat
 for name in parents:mgr.set_transform(name,T(parents[name]))
 old=mgr.in_collision_single(meshes[0],T('P02'),return_names=True)[1];new=mgr.in_collision_single(meshes[1],T('P02'),return_names=True)[1]
 if new:rows.append({'frame':i,'baseline':sorted(old),'candidate':sorted(new),'new':sorted(new-old)})
r={'frames':74,'collisions':rows,'new_collision_frames':sum(bool(r['new']) for r in rows),'method':'FCL mesh intersection; discrete approximate comparison with approved V6.5'}
(D/'motion_report.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
