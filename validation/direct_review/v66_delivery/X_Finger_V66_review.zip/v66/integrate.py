from pathlib import Path
import cadquery as cq,json
D=Path(__file__).parent;B=D.parent/'v65'
# Use the approved V6.5 dataset as immutable baseline.
B=D.parent/'v65'
d=json.loads((B/'viewer_data.json').read_text());s=cq.importers.importStep(str(D/'P02.step')).val();v,f=s.tessellate(.3,.15)
for m in d['models']:
 if m['id']=='P02':m.update(v=[list(p.toTuple()) for p in v],f=f,name='Синяя деталь P02 — расширенная V6.6')
(D/'viewer_data.json').write_text(json.dumps(d,separators=(',',':')))
h=(B/'assembly_viewer_v65.html').read_text();i=h.index('const data=')+11;j=h.index(';const canvas=',i);h=h[:i]+json.dumps(d,separators=(',',':'))+h[j:];h=h.replace('V6.5','V6.6');(D/'assembly_viewer_v66.html').write_text(h)
a=cq.Assembly()
for p in sorted((D.parent/'restored/v64').glob('P*.step')):
 a.add(s if p.stem=='P02' else cq.importers.importStep(str(p)).val(),name=p.stem)
a.add(cq.importers.importStep(str(B/'P12.step')).val(),name='P12');a.save(str(D/'assembly_v66.step'))
