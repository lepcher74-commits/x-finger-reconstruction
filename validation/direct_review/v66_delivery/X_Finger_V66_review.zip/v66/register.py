from pathlib import Path
import numpy as np,cadquery as cq,json,shutil
from PIL import Image,ImageDraw
D=Path(__file__).parent

a=np.array([[496,-423],[530,-394.]],float);b=np.array([[467.131641,-468.957898],[498.977264,-441.070303]])
u=a[1]-a[0];v=b[1]-b[0];ang=np.arctan2(v[1],v[0])-np.arctan2(u[1],u[0]);R=np.array([[np.cos(ang),np.sin(ang)],[-np.sin(ang),np.cos(ang)]]);scale=np.linalg.norm(v)/np.linalg.norm(u);t=b[0]-a[0]@R*scale
np.savez(D/'registration.npz',R=R,scale=scale,t=t)
s=cq.importers.importStep(str(D/'P02_original.step')).val();vv,ff=s.tessellate(.3);vv=np.array([p.toTuple() for p in vv]);q=(vv[:,:2]-t)@R.T/scale;q[:,1]*=-1
im=Image.open(D/'reference.png').convert('RGB');dr=ImageDraw.Draw(im)
for f in ff:dr.line([tuple(q[i]) for i in [*f,f[0]]],fill='red',width=1)
im.save(D/'side_registration.png')
print('scale',scale,'drawingbounds',q.min(0),q.max(0),'width',s.BoundingBox().zlen)
