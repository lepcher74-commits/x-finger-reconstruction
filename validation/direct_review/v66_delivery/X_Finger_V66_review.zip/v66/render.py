from pathlib import Path
import cadquery as cq,numpy as np
from PIL import Image,ImageDraw
D=Path(__file__).parent;r=np.load(D/'registration.npz');s=float(r['scale']);R=r['R'];t=r['t']
shape=cq.importers.importStep(str(D/'P02.step')).val();vs,fs=shape.tessellate(.35,.15);v=np.array([p.toTuple() for p in vs]);v[:,:2]=(v[:,:2]-t)@R.T/s;v[:,2]/=s
views=[('SIDE',np.eye(3)),('TOP',np.array([[1,0,0],[0,0,1],[0,-1,0]])),('FRONT',np.array([[0,0,1],[0,1,0],[-1,0,0]])),('REAR',np.array([[0,0,-1],[0,1,0],[1,0,0]]))]
canvas=Image.new('RGB',(1200,800),'white')
for k,(name,mat) in enumerate(views):
 vv=v@mat.T;mid=(vv.max(0)+vv.min(0))/2;vv-=mid;scale=min(530/(vv[:,0].max()-vv[:,0].min()),300/(vv[:,1].max()-vv[:,1].min()));buf=np.full((400,600,3),248,dtype=np.uint8);dep=np.full((400,600),-np.inf)
 for pts in vv[np.array(fs)]:
  pp=pts[:,:2]*[scale,-scale]+[300,210];lo=np.maximum(np.floor(pp.min(0)).astype(int),[0,0]);hi=np.minimum(np.ceil(pp.max(0)).astype(int),[599,399])
  if np.any(hi<lo):continue
  x,y=np.meshgrid(np.arange(lo[0],hi[0]+1),np.arange(lo[1],hi[1]+1));a,b,c=pp;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
  if abs(den)<1e-10:continue
  u=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/den;w=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/den;q=1-u-w;z=u*pts[0,2]+w*pts[1,2]+q*pts[2,2];sl=np.s_[lo[1]:hi[1]+1,lo[0]:hi[0]+1];hit=(u>=0)&(w>=0)&(q>=0)&(z>dep[sl]);n=np.cross(pts[1]-pts[0],pts[2]-pts[0]);n/=max(np.linalg.norm(n),1e-9);col=np.array([63,110,180])*(.5+.5*abs(n@[.2,.4,.89]));dep[sl][hit]=z[hit];buf[sl][hit]=col
 im=Image.fromarray(buf);ImageDraw.Draw(im).text((20,15),name,fill='black');canvas.paste(im,((k%2)*600,(k//2)*400))
canvas.save(D/'orthographic_review.png')
