from pathlib import Path
import cadquery as cq,json,shutil
D=Path(__file__).resolve().parent
B=D.parent/'restored/v64'; V=D.parent/'v66'
I=D/'inputs';I.mkdir(exist_ok=True)
for name in ['P04','P10','P11']:
 if not (I/(name+'.step')).exists():shutil.copy2(B/(name+'.step'),I/(name+'.step'))
s={n:cq.importers.importStep(str(I/(n+'.step'))).val() for n in ['P04','P10','P11']}
u=s['P04'].fuse(s['P10'],s['P11']).clean()
assert u.isValid() and len(u.Solids())==1
report={'name':'Тяговая чаша','id':'P13','sources':['P10 — Верхняя оболочка','P04 — Зелёная деталь','P11 — Нижняя чаша V6.4'],'valid':u.isValid(),'solids':len(u.Solids()),'volume':u.Volume(),'geometry_operation':'Boolean union in original coordinates; no bridges, offsets or reshaping','missing_source_volume':{n:s[n].cut(u).Volume() for n in s},'motion_parent':'P04','physical_scale':'Original STEP scale retained; not independently calibrated'}
(D/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
cq.exporters.export(u,str(D/'P13_traction_cup.step'));cq.exporters.export(u,str(D/'P13_traction_cup.stl'),tolerance=.15,angularTolerance=.1)
v,f=u.tessellate(.3,.15)
m={'id':'P13','parent':'P04','name':'Тяговая чаша','color':'#73b820','v':[list(p.toTuple()) for p in v],'f':f}
if V.exists():
 data=json.loads((V/'viewer_data.json').read_text()); data['models']=[a for a in data['models'] if a['id'] not in s]+[m]
 template=(V/'assembly_viewer_v66.html').read_text()
 def viewer(data,path):
  i=template.index('const data=')+11;j=template.index(';const canvas=',i)
  h=template[:i]+json.dumps(data,separators=(',',':'))+template[j:]
  h=h.replace('V6.6','V6.7').replace('Крышка P12: стенка 1,5 мм в существующем масштабе STEP. Проверочный вариант.','Тяговая чаша P13 = P10 + P04 + P11 V6.4.')
  path.write_text(h)
 viewer(data,D/'assembly_viewer_v67.html')
 data['models']=[m];viewer(data,D/'traction_cup_viewer.html')
print(json.dumps(report,ensure_ascii=False),flush=True)
