from pathlib import Path
import cadquery as cq,json,shutil
D=Path(__file__).resolve().parent
B=D.parent/'restored/v64'; V=D.parent/'v66'
I=D/'inputs';I.mkdir(exist_ok=True)
s={n:cq.importers.importStep(str(I/(n+'.step'))).val() for n in ['P01','P12']}
u=s['P01'].fuse(s['P12']).clean()
assert u.isValid() and len(u.Solids())==1
report={'name':'Вторая фаланга с крышкой','id':'P14','sources':['P01 — Чёрная деталь','P12 — Крышка из сборки V6.6 (геометрия V6.5)'],'valid':u.isValid(),'solids':len(u.Solids()),'volume':u.Volume(),'geometry_operation':'Boolean union in original coordinates; no bridges, offsets or reshaping','missing_source_volume':{n:s[n].cut(u).Volume() for n in s},'motion_parent':'P01','physical_scale':'Original STEP scale retained; not independently calibrated'}
(D/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
cq.exporters.export(u,str(D/'P14_second_phalanx_with_cover.step'));cq.exporters.export(u,str(D/'P14_second_phalanx_with_cover.stl'),tolerance=.15,angularTolerance=.1)
v,f=u.tessellate(.3,.15)
m={'id':'P14','parent':'P01','name':'Вторая фаланга с крышкой','color':'#344326','v':[list(p.toTuple()) for p in v],'f':f}
if V.exists():
 template67=(D.parent/'v67/assembly_viewer_v67.html').read_text(); start=template67.index('const data=')+11; end=template67.index(';const canvas=',start); data=json.loads(template67[start:end]); data['models']=[a for a in data['models'] if a['id'] not in s]+[m]
 template=(V/'assembly_viewer_v66.html').read_text()
 def viewer(data,path):
  i=template.index('const data=')+11;j=template.index(';const canvas=',i)
  h=template[:i]+json.dumps(data,separators=(',',':'))+template[j:]
  h=h.replace('V6.6','V6.8').replace('Крышка P12: стенка 1,5 мм в существующем масштабе STEP. Проверочный вариант.','Вторая фаланга с крышкой P14 = P01 + P12. Тяговая чаша P13 сохранена.')
  path.write_text(h)
 viewer(data,D/'assembly_viewer_v68.html')
 data['models']=[m];viewer(data,D/'second_phalanx_with_cover_viewer.html')
print(json.dumps(report,ensure_ascii=False),flush=True)
